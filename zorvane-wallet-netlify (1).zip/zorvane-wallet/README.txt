Drag this whole folder onto https://app.netlify.com/drop
index.html = the wallet (opens on Base)
_headers = security settings Netlify reads automatically
Never put your 12 words in any file here.
